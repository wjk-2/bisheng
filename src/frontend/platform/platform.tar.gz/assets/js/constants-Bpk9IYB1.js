import{ai as i,aj as r}from"./shared-components-DtfXUKAu.js";import{en as l}from"./vendor-CuSD6Dcv.js";const w=79,d="不能打开聊天窗",_="这不是聊天技能。",O="技能没有被构建",T=l,f="请在聊天前构建技能。",I=(t,o,s)=>{const n=t.id,a=i(t),e=r(s,t.id);return`import requests
from typing import Optional

BASE_API_URL = "${window.location.protocol}//${window.location.host}/api/v1/process"
FLOW_ID = "${n}"
# You can tweak the flow by adding a tweaks dictionary
# e.g {"OpenAI-XXXXX": {"model_name": "gpt-4"}}
TWEAKS = ${o&&o.length>0?p(o):JSON.stringify(a,null,2)}

def run_flow(inputs: dict, flow_id: str, tweaks: Optional[dict] = None) -> dict:
    """
    Run a flow with a given message and optional tweaks.

    :param message: The message to send to the flow
    :param flow_id: The ID of the flow to run
    :param tweaks: Optional tweaks to customize the flow
    :return: The JSON response from the flow
    """
    api_url = f"{BASE_API_URL}/{flow_id}"

    payload = {"inputs": inputs}

    if tweaks:
        payload["tweaks"] = tweaks

    response = requests.post(api_url, json=payload)
    return response.json()

# Setup any tweaks you want to apply to the flow
inputs = ${e}
print(run_flow(inputs, flow_id=FLOW_ID, tweaks=TWEAKS))`},g=(t,o,s)=>{const n=t.id,a=i(t),e=r(s,t.id);return`curl -X POST \\
  ${window.location.protocol}//${window.location.host}/api/v1/process/${n} \\
  -H 'Content-Type: application/json' \\
  -d '{"inputs": ${e}, "tweaks": ${o&&o.length>0?p(o):JSON.stringify(a,null,2)}}'`};function p(t){return t.forEach(s=>{Object.keys(s).forEach(n=>{for(let a in s[n])try{s[n][a]=JSON.parse(s[n][a])}catch{}})}),JSON.stringify(t[0],null,2)}export{_ as C,f as F,w as M,T,d as a,O as b,I as c,g};
