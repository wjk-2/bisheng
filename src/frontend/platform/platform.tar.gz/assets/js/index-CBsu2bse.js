import{cf as I,cD as U,r as y,j as e,bj as T,e8 as q,e9 as l,ea as n,b4 as Z}from"./vendor-CuSD6Dcv.js";import{B as u}from"./index-QkmTdepa.js";import{C as f,b as w,c as v,a as k}from"./index-B2BCOq33.js";import{T as g,a as N,b as t,c as i,d as _,e as r}from"./index-B9IERX_b.js";import{T as H,a as Q,b as z,c as E}from"./index-i4f04lyE.js";import{u as B,L as ee,B as se}from"./index-vqt98QkI.js";import{J as D,B as V,G as $,k as ae,l as le,m as ne,n as te,o as ie}from"./shared-components-DtfXUKAu.js";import{P as re,a as ce,b as de}from"./index-Cvcgs3nC.js";import{g as oe,c as xe}from"./constants-Bpk9IYB1.js";import{I as me}from"./index-BnjExYcV.js";const a=({name:s,type:o,desc:x,required:d=!1,example:c="",remark:h="",children:p=null,line:j=!1})=>{const{t:m}=I();return e.jsxs("div",{className:"pl-6 mb-4",children:[e.jsxs("div",{className:"relative flex justify-between mb-2",children:[e.jsxs("div",{className:"flex gap-x-4 gap-y-1 flex-wrap",children:[e.jsx(u,{variant:"outline",className:"bg-primary/15 text-primary",children:s}),e.jsx("div",{children:o}),e.jsx("div",{className:"text-gray-500",children:x})]}),d?e.jsx("span",{className:"text-red-500 min-w-12",children:m("api.required")}):e.jsx("span",{className:"text-gray-500 min-w-12",children:m("api.optional")}),j&&e.jsx("div",{className:"absolute bg-input w-6 h-[1px] -left-8 top-2.5"})]}),c&&e.jsxs("div",{className:"mb-2",children:[m("api.exampleValue"),"：",e.jsx("span",{className:"text-gray-500",children:c})]}),h&&e.jsx("div",{className:"mb-4 text-orange-500",children:h}),p&&e.jsx("div",{className:"border-l border-dashed border-input pl-2",children:p})]})},X=({})=>{const{t:s}=I(),{id:o}=U(),x=()=>`curl -X POST "${window.location.protocol}//${window.location.host}/api/v2/assistant/chat/completions" \\
-H "User-Agent: Apifox/1.0.0 (https://apifox.com)" \\
-H "Content-Type: application/json" \\
-d '{
  "model": "${o}",
  "messages": [
    {
      "role": "user",
      "content": "你好"
    }
  ],
  "temperature": 0,
  "stream": true
}'
`,d=()=>`from openai import OpenAI
base_url = "${window.location.protocol}//${window.location.host}/api/v2/assistant"
model = "${o}"
client = OpenAI(base_url=base_url, api_key="empty")
# Round 1
messages = [{"role": "user", "content": "9.11 and 9.8, 谁更大?"}]
response = client.chat.completions.create(
    model=model,
    messages=messages,
    stream=True
)
reasoning_content = ""
content = ""
for chunk in response:
    if chunk.choices[0].delta.model_extra.get("reasoning_content"):
        if not reasoning_content:
            print("\\n\\n-----Reasoning Content-----\\n")
        reasoning_chunk = chunk.choices[0].delta.reasoning_content
        print(reasoning_chunk, end='', flush=True)  # 流式打印reasoning
        reasoning_content += reasoning_chunk
    elif chunk.choices[0].delta.content:
        if not content:
            print("\\n\\n-----Final content-----\\n")
        content_chunk = chunk.choices[0].delta.content
        print(content_chunk, end='', flush=True)  # 流式打印答案
        content += content_chunk`,{message:c}=B(),h=A=>{D(A.target).then(()=>{c({variant:"success",description:s("api.copySuccess")})})},[p,j]=y.useState(!1),m=A=>{j(!0),D(A).then(()=>{setTimeout(()=>{j(!1)},2e3)})};return e.jsxs("section",{className:"max-w-[1600px] flex-grow",children:[e.jsxs(f,{className:"mb-8",children:[e.jsx(w,{children:e.jsx(v,{children:s("api.apiRequestExample")})}),e.jsxs(k,{children:[e.jsxs("h3",{className:"mb-2 bg-secondary px-4 py-2 inline-flex items-center rounded-md gap-1",children:[e.jsx(u,{children:"POST"}),e.jsx("span",{className:"hover:underline cursor-pointer",onClick:h,children:"/api/v2/assistant/chat/completions"})]}),e.jsx("p",{className:"mt-2",children:s("api.sdkNote")}),e.jsxs("p",{className:"my-2",children:[s("api.exampleCode"),"："]}),e.jsxs(H,{defaultValue:"curl",className:"w-full mb-[40px]",children:[e.jsxs(Q,{children:[e.jsx(z,{value:"curl",children:"cURL"}),e.jsx(z,{value:"python",children:"Python API"})]}),e.jsxs(E,{value:"curl",className:"relative",children:[e.jsx("button",{className:"absolute right-0 flex items-center gap-1.5 rounded bg-none p-1 text-xs text-gray-500 dark:text-gray-300",onClick:()=>m(x()),children:p?e.jsx(T,{size:18}):e.jsx(q,{size:15})}),e.jsx(l,{className:"w-full overflow-auto custom-scroll",language:"bash",style:n.oneDark,children:x()})]}),e.jsxs(E,{value:"python",className:"relative",children:[e.jsx("button",{className:"absolute right-0 flex items-center gap-1.5 rounded bg-none p-1 text-xs text-gray-500 dark:text-gray-300",onClick:()=>m(d()),children:p?e.jsx(T,{size:18}):e.jsx(q,{size:15})}),e.jsx(l,{className:"w-full overflow-auto custom-scroll",language:"python",style:n.oneDark,children:d()})]})]})]})]}),e.jsxs(f,{className:"mb-8",children:[e.jsx(w,{children:e.jsx(v,{children:s("api.requestParams")})}),e.jsx(k,{children:e.jsxs(g,{children:[e.jsx(N,{children:e.jsxs(t,{children:[e.jsxs(i,{className:"w-[60%]",children:[s("api.bodyParams")," ",e.jsx("span",{className:"bg-secondary px-2 py-1 rounded-md text-sm",children:"application/json"})]}),e.jsx(i,{children:s("api.example")})]})}),e.jsx(_,{children:e.jsxs(t,{children:[e.jsxs(r,{className:"align-top pt-6",children:[e.jsx(a,{name:"model",type:"string",desc:s("api.assistantId"),required:!0,example:o}),e.jsxs(a,{name:"messages",type:"array [object {2}] ",desc:s("api.messageList"),required:!0,children:[e.jsx(a,{name:"role",type:"string",desc:"",required:!0,example:"user",line:!0}),e.jsx(a,{name:"content",type:"string",desc:"",required:!0,example:"你好",line:!0})]}),e.jsx(a,{name:"temperature",type:"integer",desc:s("api.temperature")}),e.jsx(a,{name:"stream",type:"boolean",desc:s("api.stream")})]}),e.jsx(r,{className:"align-top",children:e.jsx(l,{className:"w-full overflow-auto custom-scroll",language:"json",style:n.oneDark,children:`{
  "model": "${o}",
  "messages": [
    {
      "role": "user",
      "content": "你好"
    }
  ],
  "temperature": 0,
  "stream": true
}`})})]})})]})})]}),e.jsxs(f,{children:[e.jsx(w,{children:e.jsx(v,{children:s("api.responseData")})}),e.jsx(k,{children:e.jsxs(g,{children:[e.jsx(N,{children:e.jsxs(t,{children:[e.jsx(i,{className:"w-[60%]",children:s("api.dataStructure")}),e.jsx(i,{children:s("api.example")})]})}),e.jsx(_,{children:e.jsxs(t,{children:[e.jsxs(r,{className:"align-top pt-6",children:[e.jsx(a,{name:"id",type:"string",desc:"",required:!0}),e.jsx(a,{name:"object",type:"string",desc:"",required:!0}),e.jsx(a,{name:"created",type:"integer",desc:"",required:!0}),e.jsxs(a,{name:"choices",type:"array [object {3}]",desc:"",required:!0,children:[e.jsx(a,{name:"index",type:"integer",desc:"",line:!0}),e.jsxs(a,{name:"message",type:"object",desc:"",line:!0,children:[e.jsx(a,{name:"role",type:"string",desc:"",required:!0,line:!0}),e.jsx(a,{name:"content",type:"string",desc:"",required:!0,line:!0})]}),e.jsx(a,{name:"finish_reason",type:"string",desc:"",line:!0})]}),e.jsxs(a,{name:"usage",type:"object ",desc:"",required:!0,children:[e.jsx(a,{name:"prompt_tokens",type:"integer",desc:"",required:!0,line:!0}),e.jsx(a,{name:"completion_tokens",type:"integer",desc:"",required:!0,line:!0}),e.jsx(a,{name:"total_tokens",type:"integer",desc:"",required:!0,line:!0})]})]}),e.jsx(r,{className:"align-top",children:e.jsx(l,{className:"w-full overflow-auto custom-scroll",language:"json",style:n.oneDark,children:`
{
  "id": "148964adf7ec439f87a6240289735740",
  "object": "chat.completion",
  "created": 1720755036,
  "model": "a31d044d-af13-43da-b715-d87a29569809",
  "choices": [
    {
      "index": 0,
      "message": {
        "role": "assistant",
        "content": "你好，有什么可以帮你的？"
      },
      "finish_reason": "stop"
    }
  ]
}`})})]})})]})})]})]})};var C={BASE_URL:""};const ue=()=>{const{t:s}=I(),{id:o}=U(),{message:x}=B(),d=m=>{D(m.target).then(()=>{x({variant:"success",description:s("api.copySuccess")})})},[c,h]=y.useState(!1),p=m=>{h(!0),D(m).then(()=>{setTimeout(()=>{h(!1)},2e3)})},j=`import requests
import json

url = "${location.origin}/api/v2/workflow/invoke"

payload = json.dumps({
   "workflow_id": "${o}",
   "stream": False, # 是否请求流式返回工作流事件，默认为 True。本示例为了直观展示返回结果，所以改为False 使用非流式请求，真实业务场景中为了用户体验建议请求流式返回。
})

headers = {
   'Content-Type': 'application/json'
}

response = requests.request("POST", url, headers=headers, data=payload)

print(response.text)# 输出工作流的响应`;return e.jsxs("section",{className:"max-w-[1600px] flex-grow",children:[e.jsxs(f,{className:"mb-8",children:[e.jsx(w,{children:e.jsx(v,{id:"guide-t1",children:"接口基本信息"})}),e.jsxs(k,{children:[e.jsx("h3",{className:"py-2",id:"guide-word",children:"1. 工作流请求执行接口"}),e.jsxs("h3",{className:"mb-2 bg-secondary px-4 py-2 inline-flex items-center rounded-md gap-1",children:[e.jsx(u,{children:"POST"})," ",e.jsxs("span",{className:"hover:underline cursor-pointer",onClick:d,children:[location.origin,"/api/v2/workflow/invoke"]})]}),e.jsx("h3",{className:"py-2",id:"guide-word",children:"2. 工作流停止运行接口"}),e.jsxs("h3",{className:"mb-2 bg-secondary px-4 py-2 inline-flex items-center rounded-md gap-1",children:[e.jsx(u,{children:"POST"})," ",e.jsxs("span",{className:"hover:underline cursor-pointer",onClick:d,children:[location.origin,"/api/v2/workflow/stop"]})]})]})]}),e.jsxs(f,{className:"mb-8",children:[e.jsx(w,{children:e.jsx(v,{id:"guide-t2",children:"整体调用流程"})}),e.jsxs(k,{children:[e.jsx("div",{className:"w-[700px] mx-auto",children:e.jsx("img",{src:C.BASE_URL+"/assets/api/flow.png",className:"size-full",alt:""})}),e.jsx("p",{className:"eagent-label pb-2",children:"如时序图所示，在对接工作流 API 时，一般会经历以下步骤："}),e.jsxs("p",{className:"eagent-label pb-2",children:[e.jsx("span",{className:"font-semibold",children:"1. 第一步："}),"发起工作流执行。通过/invoke 接口让工作流从开始节点开始运行："]}),e.jsxs("div",{className:"relative  max-w-[80vw]",children:[e.jsx("button",{className:"absolute right-0 flex items-center gap-1.5 rounded bg-none p-1 text-xs text-gray-500 dark:text-gray-300",onClick:()=>p(j),children:c?e.jsx(T,{size:18}):e.jsx(q,{size:15})}),e.jsx(l,{className:"w-full overflow-auto custom-scroll text-sm",language:"json",style:n.oneDark,children:j})]}),e.jsxs("p",{className:"eagent-label py-2",children:[e.jsx("span",{className:"font-semibold",children:"2. 第二步："}),"获取并解析工作流返回的事件。（一定要保留 session_id 等上下文信息，以便后续继续请求）"]}),e.jsx(l,{className:"w-full max-w-[80vw] overflow-auto custom-scroll text-sm",language:"json",style:n.oneDark,children:`{
    "status_code": 200,
    "status_message": "SUCCESS",
    "data": {
        "session_id": "d4347ab8e8cd48c48ac9920dbb5a9b35_async_task_id",
        "events": [
            {
                "event": "guide_word",
                "message_id": null,
                "status": "end",
                "node_id": "start_553b9",
                "node_execution_id": "ce9a73b376c647159b1b2de1806129cf",
                "output_schema": {
                    "message": "您好，请问想聊些什么呢？",
                    "reasoning_content": null,
                    "output_key": null,
                    "files": null,
                    "source_url": null,
                    "extra": null
                },
                "input_schema": null
            },
            {
                "event": "input",
                "message_id": "387216",
                "status": "end",
                "node_id": "input_2775b",
                "node_execution_id": null,
                "output_schema": null,
                "input_schema": {
                    "input_type": "dialog_input",
                    "value": [
                        {
                            "key": "user_input",
                            "type": "text",
                            "value": null,
                            "label": null,
                            "multiple": false,
                            "required": true,
                            "options": null
                        }
                    ]
                }
            }
        ]
    }
}`}),e.jsxs("div",{className:"mb-6",children:[e.jsxs("p",{className:"eagent-label py-2",children:[e.jsx("span",{className:"font-semibold",children:"3. 第三步："}),"根据事件类型渲染前端，并收集用户输入。"]}),e.jsxs("ul",{className:"list-disc list-inside pl-4 mt-2 eagent-label pb-2",children:[e.jsxs("li",{className:"mt-2 leading-6",children:["如果事件是 ",e.jsx("strong",{children:"普通输出"}),"（比如 ",e.jsx("code",{className:"bg-gray-200 py-1 rounded",children:'event="output_msg"'}),"），则直接展示内容。"]}),e.jsxs("li",{className:"mt-2 leading-6",children:["如果事件是 ",e.jsx("strong",{children:"等待用户交互输入"}),"（比如 ",e.jsx("code",{className:"bg-gray-200 p-1 rounded",children:'event="input"'})," 或 ",e.jsx("code",{className:"bg-gray-200 p-1 rounded",children:'event="output_with_input_msg"'})," 或 ",e.jsx("code",{class:"bg-gray-200 p-1 rounded",children:'event="output_with_choose_msg"'}),"），则需要渲染对应的界面（对话框、表单等）。"]})]})]}),e.jsxs("p",{className:"eagent-label py-2",children:[e.jsx("span",{className:"font-semibold",children:"4. 第四步："}),"带着用户输入再次调用 ",e.jsx("code",{className:"bg-gray-200 p-1 rounded",children:"/invoke"})," 接口。"]}),e.jsx(l,{className:"w-full max-w-[80vw] overflow-auto custom-scroll text-sm",language:"json",style:n.oneDark,children:`payload = json.dumps({
    "workflow_id": "7481368b-dd1c-43ef-a254-dce219ee53e8",
    "stream": False,  # 启用流式传输
    "input": {"input_2775b": {  # 事件里的节点ID
        "user_input": "贵州茅台股价情况"  # 用户输入内容
    }},
    "message_id": "387216",
    "session_id": "1fc60fe0edb44219bbef5f8870dd4639_async_task_id"
})
`}),e.jsxs("p",{className:"eagent-label py-2",children:[e.jsx("span",{className:"font-semibold",children:"5. 第五步："}),"继续获取并解析返回的事件……直到返回 ",e.jsx("code",{className:"bg-gray-100 p-1 rounded",children:"close"})," 事件（非必须）结束工作流运行，也可调用 ",e.jsx("code",{className:"bg-gray-100 p-1 rounded",children:"POST /workflow/stop"})," 接口手动终止工作流。"]})]})]}),e.jsxs(f,{className:"mb-8",children:[e.jsx(w,{children:e.jsx(v,{id:"guide-t3",children:"返回事件类型与处理方式"})}),e.jsxs(k,{className:"relative",children:[e.jsx("p",{className:"eagent-label py-2",children:"工作流返回的响应 JSON 通常包含一个或多个事件对象（数组形式），每个事件的字段可能不一样，以下枚举全部字段情况（非真实值，仅供参考）："}),e.jsxs(g,{children:[e.jsx(N,{children:e.jsxs(t,{children:[e.jsx(i,{className:"min-w-[600px]",children:s("api.dataStructure")}),e.jsx(i,{className:"",children:s("api.example")})]})}),e.jsx(_,{children:e.jsxs(t,{children:[e.jsxs(r,{className:"align-top",children:[e.jsx(a,{name:"event",required:!0,type:"str",desc:"事件名称"}),e.jsx(a,{name:"node_id",required:!0,type:"str",desc:"触发事件的节点ID"}),e.jsx(a,{name:"message_id",required:!0,type:"str",desc:"消息在数据库中的唯一ID"}),e.jsx(a,{name:"node_execution_id",required:!0,type:"str",desc:"执行此节点时的唯一ID"}),e.jsxs(a,{name:"input_schema",required:!0,type:"Json",desc:"需要用户输入的schema",children:[e.jsx(a,{line:!0,name:"input_type",type:"str",desc:"输入类型",example:"form_input",remark:"输入方式"}),e.jsxs(a,{line:!0,name:"value",type:"JsonArray",desc:"需要用户输入的字段信息",children:[e.jsx(a,{line:!0,name:"key",type:"str",desc:"字段的唯一key",example:"category"}),e.jsx(a,{line:!0,name:"type",type:"str",desc:"字段类型",example:"select"}),e.jsx(a,{line:!0,name:"value",type:"str",desc:"字段的默认值",example:""}),e.jsx(a,{line:!0,name:"multiple",type:"boolean",desc:"是否支持多选",example:"True"}),e.jsx(a,{line:!0,name:"label",type:"str",desc:"字段的展示名称",example:"请选择接下来要进行的操作"}),e.jsxs(a,{line:!0,name:"options",type:"JsonArray",desc:"下拉框类型的选项列表",children:[e.jsx(a,{line:!0,name:"id",type:"str",desc:"选项的唯一ID",example:"0b8a2fe9"}),e.jsx(a,{line:!0,name:"text",type:"str",desc:"选项的文本",example:"操作1"}),e.jsx(a,{line:!0,name:"type",type:"str",desc:"选项类型",example:""})]}),e.jsx(a,{line:!0,name:"required",type:"boolean",desc:"是否必填",example:"True"})]})]}),e.jsxs(a,{name:"output_schema",required:!0,type:"Json",desc:"输出schema",children:[e.jsx(a,{line:!0,name:"message",type:"str",desc:"输出的内容"}),e.jsx(a,{line:!0,name:"reasoning_content",type:"str",desc:"推理模型的思考过程内容"}),e.jsx(a,{line:!0,name:"output_key",type:"str",desc:"输出内容对应的变量key",example:"output"}),e.jsxs(a,{line:!0,name:"files",type:"JsonArray",desc:"文件列表",children:[e.jsx(a,{line:!0,name:"path",type:"str",desc:"文件路径",example:"http://minio:9000/xxx.png?aa=xxx"}),e.jsx(a,{line:!0,name:"name",type:"str",desc:"文件名称",example:"测试图片.png"})]}),e.jsx(a,{line:!0,name:"source_url",type:"str",desc:"溯源url",example:""}),e.jsx(a,{line:!0,name:"extra",type:"str",desc:"QA知识库溯源内容",example:'{"qa": "本答案来源于已有问答库: QA 知识库", "url": null}'})]})]}),e.jsx(r,{className:"align-top",children:e.jsx(l,{className:"w-full overflow-auto custom-scroll",language:"json",style:n.oneDark,children:`{
  "event": "guide_word",  
  # 表示当前事件类型，例如 guide_word（开场白事件）、guide_question（引导问题事件）、input（等待输入事件）、output_msg（输出事件）、close（结束事件）……
  
  "node_id": "input_xxxx",  
  # 当前事件是由哪个工作流节点触发的。对于需要输入的事件（如 event="input"），必须在后续请求中携带此 node_id ，以告诉后端对哪个节点进行输入。 
  
  "message_id": "xxxxxxx",  
  # 消息在数据库中的唯一ID
  
  "node_execution_id": "xxxxx",  
  # 此节点时的唯一执行ID。由于同一个节点可能在运行过程中执行多次，该字段用于唯一标识某次节点执行，在流式输出事件中，需要用它来区分多条流式消息。
  
  "input_schema": {   # input_schema ：需要用户输入的schema，此字段不为空 则需要给用户渲染对应的输入UI
    "input_type": "form_input",  
    # input_type：输入类型。取值范围包括：1) form_input：表单形式的输入；2) dialogue_input：对话框形式的用户输入；3)message_inline_input：需要用户输入的消息;4)需要用户选择的消息。
    
    "value": [  # 需要用户输入哪些字段信息，随着 input_type 类型不同，需要填写不同的字段
      {
        "key": "category",  # 字段的唯一key，拼接用户输入时，使用此key
        "type": "select",  # 字段类型，1）text：文本输入框；2）file：文件上传；3）select：下拉框
        "value": "",  # 字段的默认值
        "multiple": True,  # type=select时，通过此字段指定下拉框是否可多选
        "label": "请选择接下来要进行的操作",  # 字段的前端展示名称
        "options": [  # 如果 type=select，则在这里列出可选值的 id、text 等信息
          {
            "id": "0b8a2fe9",
            "text": "操作1",
            "type": ""
          },
          {
            "id": "eb5f4ade",
            "text": "操作2",
            "type": ""
          }
        ],  
        "required": True  # 是否必填
      }
    ]
  },
  "output_schema": {# 需要在用户会话界面展示的数据
    "message": "输出内容",  # 直接展示给用户的文本输出内容。
    "reasoning_content"："思考过程内容" # R1 等推理模型的思考过程内容
    "output_key": "output",  # 输出内容对应的变量标识
    "files": [  # 文件文件列表，每个文件包含 path 和 name 信息。前端可据此展示文件列表，允许用户下载或者预览。
      {
        "path": "http://minio:9000/xxx.png?aa=xxx",
        "name": "测试图片.png"
      }
    ],
    "source_url": "",  # 知识库问答溯源页面地址，需要自己拼接 E-Agent 的前端地址。具体是否支持溯源请参考产品文档
    "extra": "{"qa": "本答案来源于已有问答库: QA 知识库", "url": null}"  # QA知识库溯源内容
  },
}`})})]})})]}),e.jsxs(re,{children:[e.jsx(ce,{asChild:!0,children:e.jsx(V,{className:"fixed top-20 right-10 z-10 size-11 rounded-full",children:"导航"})}),e.jsxs(de,{className:"p-4 shadow-lg flex flex-col gap-2",children:[e.jsxs(u,{variant:"gray",className:"p-2",children:[e.jsx("span",{className:"size-2 rounded-full bg-[#000] mr-2"}),e.jsx("a",{href:"#guide-t1",children:"接口基本信息"})]}),e.jsxs(u,{variant:"gray",className:"p-2",children:[e.jsx("span",{className:"size-2 rounded-full bg-[#000] mr-2"}),e.jsx("a",{href:"#guide-t2",children:"整体调用流程"})]}),e.jsxs(u,{variant:"gray",className:"p-2",children:[e.jsx("span",{className:"size-2 rounded-full bg-[#000] mr-2"}),e.jsx("a",{href:"#guide-t3",children:"返回事件类型与处理方式"})]}),e.jsxs("div",{className:"pl-4 flex flex-col gap-2",children:[e.jsxs(u,{variant:"gray",className:"p-2",children:[e.jsx("span",{className:"size-2 rounded-full bg-[#FFD89A] mr-2"}),e.jsx("a",{href:"#guide-2",children:"引导问题事件"})]}),e.jsxs(u,{variant:"gray",className:"p-2",children:[e.jsx("span",{className:"size-2 rounded-full bg-primary mr-2"}),e.jsx("a",{href:"#guide-3",children:"等待输入事件-对话框形式"})]}),e.jsxs(u,{variant:"gray",className:"p-2",children:[e.jsx("span",{className:"size-2 rounded-full bg-primary mr-2"}),e.jsx("a",{href:"#guide-5",children:"等待输入事件-表单形式"})]}),e.jsxs(u,{variant:"gray",className:"p-2",children:[e.jsx("span",{className:"size-2 rounded-full bg-[#BBDBFF] mr-2"}),e.jsx("a",{href:"#guide-6",children:"输出事件"})]}),e.jsxs(u,{variant:"gray",className:"p-2",children:[e.jsx("span",{className:"size-2 rounded-full bg-[#BBDBFF] mr-2"}),e.jsx("a",{href:"#guide-7",children:"输出事件-需输入类型"})]}),e.jsxs(u,{variant:"gray",className:"p-2",children:[e.jsx("span",{className:"size-2 rounded-full bg-[#BBDBFF] mr-2"}),e.jsx("a",{href:"#guide-8",children:"输出事件-选择类型"})]}),e.jsxs(u,{variant:"gray",className:"p-2",children:[e.jsx("span",{className:"size-2 rounded-full bg-[#FFD89A] mr-2"}),e.jsx("a",{href:"#guide-9",children:"流式输出事件-输出中"})]}),e.jsxs(u,{variant:"gray",className:"p-2",children:[e.jsx("span",{className:"size-2 rounded-full bg-[#FFD89A] mr-2"}),e.jsx("a",{href:"#guide-10",children:"流式输出事件-结束"})]}),e.jsxs(u,{variant:"gray",className:"p-2",children:[e.jsx("span",{className:"size-2 rounded-full bg-red-400 mr-2"}),e.jsx("a",{href:"#guide-11",children:"结束事件"})]})]})]})]}),e.jsx("h3",{className:"mt-8",id:"guide-1",children:"开场白事件"}),e.jsxs(g,{children:[e.jsx(N,{children:e.jsxs(t,{children:[e.jsx(i,{className:"w-[300px]",children:"样式预览"}),e.jsx(i,{className:"",children:s("api.example")})]})}),e.jsx(_,{children:e.jsxs(t,{children:[e.jsx(r,{className:"align-top",children:e.jsx("div",{className:"max-w-[300px]",children:e.jsx("img",{src:C.BASE_URL+"/assets/api/chat1.png",className:"size-full",alt:""})})}),e.jsx(r,{className:"align-top",children:e.jsx(l,{className:"w-full overflow-auto custom-scroll",language:"json",style:n.oneDark,children:`{
  "event": "guide_word",  # 开场白事件
  "node_id": "start_xxx",  # 节点ID，
  "node_execution_id": "xxxxxxxx",  # 执行此节点的唯一标识
  "output_schema": {  # output
    "message": "本工作流可以解决xxxx等问题"
  }
}`})})]})})]}),e.jsx("p",{className:"eagent-label mt-2",children:"处理逻辑：将 output_schema.message 展示给用户即可。"}),e.jsx("h3",{className:"mt-8",id:"guide-2",children:"引导问题事件"}),e.jsx("p",{className:"eagent-label mt-2",children:"事件数据示例"}),e.jsxs(g,{children:[e.jsx(N,{children:e.jsxs(t,{children:[e.jsx(i,{className:"w-[300px]",children:"样式预览"}),e.jsx(i,{className:"",children:s("api.example")})]})}),e.jsx(_,{children:e.jsxs(t,{children:[e.jsx(r,{className:"align-top",children:e.jsx("div",{className:"max-w-[300px]",children:e.jsx("img",{src:C.BASE_URL+"/assets/api/chat2.png",className:"size-full",alt:""})})}),e.jsx(r,{className:"align-top",children:e.jsx(l,{className:"w-full overflow-auto custom-scroll",language:"json",style:n.oneDark,children:`{
  "event": "guide_question",
  "node_id": "start_xxx",
  "node_execution_id": "xxxxxxxx",
  "output_schema": {
    "message": [
      "引导问题1",
      "引导问题2"
    ]
  }
}`})})]})})]}),e.jsx("p",{className:"eagent-label mt-2",children:"处理逻辑：向用户展示引导问题列表，将用户选中的问题作为输入，继续调用工作流接口。"}),e.jsx("h3",{className:"mt-8",id:"guide-3",children:"等待输入事件-对话框形式"}),e.jsxs("div",{className:"border border-red-200 rounded-sm bg-orange-100 p-4 text-sm",children:[e.jsxs("p",{className:"eagent-label",children:["当工作流返回 ",e.jsx("span",{className:"bg-orange-50",children:'event="input"'})," 且 ",e.jsx("span",{className:"bg-orange-50",children:'input_type="dialog_input"'}),"时，表示后端希望前端在对话框中接收用户输入以及上传文件（非必须）。"]}),e.jsxs("p",{className:"eagent-label mt-2",children:["下一次请求 ",e.jsx("span",{className:"bg-orange-50",children:"/invoke"})," 接口必带的关键字段是 ",e.jsx("span",{className:"bg-orange-50",children:"node_id"}),",",e.jsx("span",{className:"bg-orange-50",children:"message_id"}),",",e.jsx("span",{className:"bg-orange-50",children:"session_id"})," 以及对话框输入。"]})]}),e.jsx("p",{className:"eagent-label mt-2",children:"事件数据示例"}),e.jsxs(g,{children:[e.jsx(N,{children:e.jsxs(t,{children:[e.jsx(i,{className:"w-[300px]",children:"样式预览"}),e.jsx(i,{className:"",children:s("api.example")})]})}),e.jsx(_,{children:e.jsxs(t,{children:[e.jsx(r,{className:"align-top",children:e.jsx("div",{className:"max-w-[300px]",children:e.jsx("img",{src:C.BASE_URL+"/assets/api/output.png",className:"size-full",alt:""})})}),e.jsx(r,{className:"align-top",children:e.jsx(l,{className:"w-full overflow-auto custom-scroll",language:"json",style:n.oneDark,children:`{
    "event": "input",# 等待输入事件
    "node_id": "input_xxxx",
    "node_execution_id": "xxxxx",
    "input_schema": {
        "input_type": "dialog_input",# 对话框形式
        "value": [
            {
                "key": "user_input",
                "type": "text"
            },
            {
                "key": "dialog_files_content", # 需要用户上传文件
                "type": "dialog_file"
            },
            {
                "key": "dialog_file_accept",  # 上传文件的格式限制
                "type": "dialog_file_accept",
                "value": "all"  # 允许的文件类型
            }
        ]
    }
}`})})]})})]}),e.jsxs("div",{className:"mb-6",children:[e.jsx("p",{className:"eagent-label py-2",children:"处理逻辑："}),e.jsxs("ul",{className:"list-disc list-inside pl-4 mt-2 eagent-label pb-2",children:[e.jsx("li",{className:"mt-2 leading-6",children:"绘制对话框，接收用户输入内容"}),e.jsxs("li",{className:"mt-2 leading-6",children:["携带 ",e.jsx("code",{className:"bg-gray-200 p-1 rounded",children:"node_id"}),"、",e.jsx("code",{className:"bg-gray-200 p-1 rounded",children:"session_id"}),"、",e.jsx("code",{className:"bg-gray-200 p-1 rounded",children:"message_id"})," 再次请求 /workflow/invoke"]}),e.jsx("li",{className:"mt-2 leading-6",children:"如果用户没有在对话框内上传文件，请求示例如下"})]})]}),e.jsx(l,{className:"w-full max-w-[80vw] overflow-auto custom-scroll",language:"json",style:n.oneDark,children:`payload = json.dumps({
    "workflow_id": "c90bb7f2-b7d1-49bf-9fb6-3ab60ff8e414",
    "session_id": "d4347ab8e8cd48c48ac9920dbb5a9b35_async_task_id",  # 上次返回的 session_id
    "message_id": "385140",
    "input": {
        "input_2775b": {  # 这里对应返回事件里的 node_id
            # input_schema.value中元素的 key 以及对应要传入的值
            "user_input": "你好"
        }
    }
})`}),e.jsx("div",{className:"mb-6",children:e.jsxs("ul",{className:"list-disc list-inside pl-4 mt-2 eagent-label pb-2",children:[e.jsx("li",{className:"mt-2 leading-6",children:"如果用户在对话框内上传了文件"}),e.jsx("ul",{className:"list-disc list-inside pl-4 mt-2 eagent-label pb-2",children:e.jsx("li",{className:"mt-2 leading-6",children:"如果有文件类型，调用 E-Agent 文件上传接口获取到文件url，示例如下："})})]})}),e.jsx(l,{className:"w-full max-w-[80vw] overflow-auto custom-scroll",language:"json",style:n.oneDark,children:`import requests
def upload_file(local_path: str):
    server = "http://ip:port"
    url = server + '/api/v1/knowledge/upload'
    headers = {}
    files = {'file': open(local_path, 'rb')}
    res = requests.post(url, headers=headers, files=files)
    file_path = res.json()['data'].get('file_path', '')
    return file_path
    
 financeA = upload_file("caibao.pdf")
 financeB = upload_file("caibao2.pdf")`}),e.jsx("div",{className:"mb-6",children:e.jsx("ul",{className:"list-disc list-inside pl-4 mt-2 eagent-label pb-2",children:e.jsx("ul",{className:"list-disc list-inside pl-4 mt-2 eagent-label pb-2",children:e.jsx("li",{className:"mt-2 leading-6",children:"成功获取用户的输入和上传文件的url后，拼接为如下格式的接口入参"})})})}),e.jsx(l,{className:"w-full overflow-auto custom-scroll",language:"json",style:n.oneDark,children:`payload = json.dumps({
    "workflow_id": "c90bb7f2-b7d1-49bf-9fb6-3ab60ff8e414",
    "session_id": "d4347ab8e8cd48c48ac9920dbb5a9b35_async_task_id",  # 上次返回的 session_id
    "message_id": "385140",
    "input": {
        "input_2775b": {  # 这里对应返回事件里的 node_id
            # input_schema.value中元素的 key 以及对应要传入的值
            "user_input": "你好",
            # 上传文件后获取到的文件url列表
            "dialog_files_content": ["minio://127.0.0.1:9000/xxxx"]
        }
    }
})
`}),e.jsx("h3",{className:"mt-8",id:"guide-5",children:"等待输入事件-表单形式"}),e.jsxs("div",{className:"border border-red-200 rounded-sm bg-orange-100 p-4 text-sm",children:[e.jsxs("p",{className:"eagent-label",children:["当工作流返回 ",e.jsx("span",{className:"bg-orange-50",children:'event="input"'})," 且 ",e.jsx("span",{className:"bg-orange-50",children:'input_type="form_input"'}),"时，后端希望前端渲染一个表单，让用户填写内容。"]}),e.jsxs("p",{className:"eagent-label mt-2",children:["下一次请求 ",e.jsx("span",{className:"bg-orange-50",children:"/invoke"})," 接口必带的字段是 ",e.jsx("span",{className:"bg-orange-50",children:"node_id"}),", ",e.jsx("span",{className:"bg-orange-50",children:"message_id"}),", ",e.jsx("span",{className:"bg-orange-50",children:"session_id"})," 以及用户填写的表单值。"]})]}),e.jsx("p",{className:"eagent-label mt-2",children:"事件数据示例"}),e.jsxs(g,{children:[e.jsx(N,{children:e.jsxs(t,{children:[e.jsx(i,{className:"w-[300px]",children:"样式预览"}),e.jsx(i,{className:"",children:s("api.example")})]})}),e.jsx(_,{children:e.jsxs(t,{children:[e.jsx(r,{className:"align-top",children:e.jsx("div",{className:"max-w-[300px]",children:e.jsx("img",{src:C.BASE_URL+"/assets/api/chat4.png",className:"size-full",alt:""})})}),e.jsx(r,{className:"align-top",children:e.jsx(l,{className:"w-full overflow-auto custom-scroll",language:"json",style:n.oneDark,children:`{
    "event": "input",
    "node_id": "input_xxxx",
    "node_execution_id": "xxxxx",
    "input_schema": {
        "input_type": "form_input",
        "value": [
            {
                "key": "text_input",
                "type": "text",
                "value": "文本输入类型",
                "label": "文本输入类型",
                "options": [],
                "required": true
            },
            {
                "key": "file",
                "type": "file",
                "value": "",
                "label": "文件类型的输入",
                "options": [],
                "required": true
            },
            {
                "key": "category",
                "type": "select",
                "value": "",
                "label": "下拉框类型",
                "required": true,
                "multiple": false,
                "options": [
                    {
                        "id": "0b8a2fe9",
                        "text": "选项1",
                        "type": ""
                    },
                    {
                        "id": "eb5f4ade",
                        "text": "选项2",
                        "type": ""
                    }
                ]
            }
        ]
    }
}`})})]})})]}),e.jsxs("div",{className:"mb-6",children:[e.jsx("p",{className:"eagent-label py-2",children:"处理逻辑："}),e.jsxs("ul",{className:"list-disc list-inside pl-4 mt-2 eagent-label pb-2",children:[e.jsxs("li",{className:"mt-2 leading-6",children:["解析",e.jsx("code",{className:"bg-gray-200 p-1 rounded",children:"input_schema.value"})," 中的表单元素，在前端渲染表单样式"]}),e.jsx("li",{className:"mt-2 leading-6",children:"如果有文件类型，调用 E-Agent 文件上传接口获取到文件url，示例如下："})]})]}),e.jsx(l,{className:"w-full max-w-[80vw] overflow-auto custom-scroll",language:"json",style:n.oneDark,children:`import requests
def upload_file(local_path: str):
    server = "http://ip:port"
    url = server + '/api/v1/knowledge/upload'
    headers = {}
    files = {'file': open(local_path, 'rb')}
    res = requests.post(url, headers=headers, files=files)
    file_path = res.json()['data'].get('file_path', '')
    return file_path
    
 financeA = upload_file("caibao.pdf")
 financeB = upload_file("caibao2.pdf")`}),e.jsxs("p",{className:"mt-4 eagent-label",children:["3. 提交时，JSON 中要和返回的 ",e.jsx("code",{className:"bg-gray-200 p-1 rounded",children:"key"})," 对应，并带上 ",e.jsx("code",{className:"bg-gray-200 p-1 rounded",children:"session_id"}),"、",e.jsx("code",{className:"bg-gray-200 p-1 rounded",children:"message_id"}),"、",e.jsx("code",{className:"bg-gray-200 p-1 rounded",children:"node_id"})," 等必备信息。"]}),e.jsx(l,{className:"w-full max-w-[80vw] overflow-auto custom-scroll",language:"json",style:n.oneDark,children:`{
    "workflow_id": "xxxxx",
    "session_id": "使用接口返回的session_id",
    "message_id": "xxxxx",
    "input": {
        "input_xxx": {  # 事件里的 node_id
            # key是input_schema.value中元素的 key 以及对应要传入的值
            "text_input": "用户输入的内容",
            "file": ["minio://127.0.0.1:9000/xxxx"] # 用户上传文件获取到的文件url, 允许多选就是多个url
            "category": "选项2" # 将选项内容赋值给变量。当允许多选时，多个选项内容通过逗号分隔。
        }
    }
}`}),e.jsx("h3",{className:"mt-8",id:"guide-6",children:"输出事件"}),e.jsx("p",{className:"eagent-label py-2",children:"事件数据示例"}),e.jsxs(g,{children:[e.jsx(N,{children:e.jsxs(t,{children:[e.jsx(i,{className:"w-[300px]",children:"样式预览"}),e.jsx(i,{className:"",children:s("api.example")})]})}),e.jsx(_,{children:e.jsxs(t,{children:[e.jsx(r,{className:"align-top",children:e.jsxs("div",{className:"max-w-[300px]",children:[e.jsx("img",{src:C.BASE_URL+"/assets/api/chat5.png",className:"size-full",alt:""}),e.jsx("img",{src:C.BASE_URL+"/assets/api/chat6.png",className:"size-full",alt:""})]})}),e.jsx(r,{className:"align-top",children:e.jsx(l,{className:"w-full overflow-auto custom-scroll",language:"json",style:n.oneDark,children:`{
  "event": "output_msg",
  "node_id": "output_xxx",
  "node_execution_id": "xxxxxxxxx",
  "output_schema": {
    "message": "输出内容",
    "output_key": "output",
    "files": [
      {
        "path": "http://minio:9000/xxx.png?aa=xxx",
        "name": "测试图片.png"
      }
    ],
    "source_url": ""
  }
}`})})]})})]}),e.jsxs("div",{className:"mb-6",children:[e.jsx("p",{className:"eagent-label py-2",children:"处理逻辑："}),e.jsxs("ul",{className:"list-disc list-inside pl-4 mt-2 eagent-label pb-2",children:[e.jsxs("li",{className:"mt-2 leading-6",children:["将 ",e.jsx("code",{className:"bg-gray-200 p-1 rounded",children:"output_schema.message"})," 展示给用户"]}),e.jsxs("li",{className:"mt-2 leading-6",children:["如果 ",e.jsx("code",{className:"bg-gray-200 p-1 rounded",children:"files"})," 不为空，则提供文件下载按钮或预览功能"]}),e.jsxs("li",{className:"mt-2 leading-6",children:[e.jsx("code",{className:"bg-gray-200 p-1 rounded",children:"source_url"})," 基于 E-Agent 服务根路径，需要拼接 E-Agent 访问地址才可访问"]})]})]}),e.jsx("h3",{className:"mt-8",id:"guide-7",children:"输出事件-需输入类型"}),e.jsx("div",{className:"border border-red-200 rounded-sm bg-orange-100 p-4 text-sm",children:e.jsx("p",{className:"eagent-label",children:"此时工作流处于待输入状态"})}),e.jsx("p",{className:"eagent-label mt-2",children:"事件数据示例"}),e.jsxs(g,{children:[e.jsx(N,{children:e.jsxs(t,{children:[e.jsx(i,{className:"w-[300px]",children:"样式预览"}),e.jsx(i,{className:"",children:s("api.example")})]})}),e.jsx(_,{children:e.jsxs(t,{children:[e.jsx(r,{className:"align-top",children:e.jsx("div",{className:"max-w-[300px]",children:e.jsx("img",{src:C.BASE_URL+"/assets/api/chat6.png",className:"size-full",alt:""})})}),e.jsx(r,{className:"align-top",children:e.jsx(l,{className:"w-full overflow-auto custom-scroll",language:"json",style:n.oneDark,children:`{
    "event": "output_with_input_msg",
    "node_id": "output_ 123",
    "node_execution_id": "xxxxxxxxx",
    "message_id": "xxxxx",
    "output_schema": {
        "message": "输出内容",
        "output_key": "output",
        "files": [
            {
                "path": "http://minio:9000/xxx.png?aa=xxx",
                "name": "测试图片.png"
            }
        ],
        "source_url": ""
    },
    "input_schema": {
        "input_type": "message_inline_input",
        "value": [
            {
                "key": "output_result",
                "type": "text",
                "value": "以下是AI生成的的草稿：XXXX"
            }
        ]
    }
}`})})]})})]}),e.jsxs("div",{className:"mb-6",children:[e.jsx("p",{className:"eagent-label py-2",children:"处理逻辑："}),e.jsxs("ul",{className:"list-disc list-inside pl-4 mt-2 eagent-label pb-2",children:[e.jsxs("li",{className:"mt-2 leading-6",children:["展示 ",e.jsx("code",{className:"bg-gray-200 p-1 rounded",children:"output_schema"})," 内容"]}),e.jsxs("li",{className:"mt-2 leading-6",children:["根据 ",e.jsx("code",{className:"bg-gray-200 p-1 rounded",children:"input_schema"})," 在消息体中绘制输入框，",e.jsx("code",{className:"bg-gray-200 p-1 rounded",children:"input_schema.value.value"})," 为输入框内的默认值，用户可在其基础上二次编辑"]}),e.jsx("li",{className:"mt-2 leading-6",children:"用户编辑或确认后，再次调用 API 提交。示例如下："})]})]}),e.jsx(l,{className:"w-full overflow-auto custom-scroll",language:"json",style:n.oneDark,children:`{
    "workflow_id": "xxxxx",
    "session_id": "使用接口返回的session_id",
    "message_id": "消息的唯一ID",
    "input": {
        "output_123": {  # 事件里的节点ID
            # key是input_schema.value中元素的key
            "output_result": "用户输入的内容"
        }
    }
}`}),e.jsx("h3",{className:"mt-8",id:"guide-8",children:"输出事件-选择类型"}),e.jsx("div",{className:"border border-red-200 rounded-sm bg-orange-100 p-4 text-sm",children:e.jsx("p",{className:"eagent-label",children:"此时工作流处于待输入状态"})}),e.jsx("p",{className:"eagent-label mt-2",children:"事件数据示例"}),e.jsxs(g,{children:[e.jsx(N,{children:e.jsxs(t,{children:[e.jsx(i,{className:"w-[300px]",children:"样式预览"}),e.jsx(i,{className:"",children:s("api.example")})]})}),e.jsx(_,{children:e.jsxs(t,{children:[e.jsx(r,{className:"align-top",children:e.jsx("div",{className:"max-w-[300px]",children:e.jsx("img",{src:C.BASE_URL+"/assets/api/chat7.png",className:"size-full",alt:""})})}),e.jsx(r,{className:"align-top",children:e.jsx(l,{className:"w-full overflow-auto custom-scroll",language:"json",style:n.oneDark,children:`{
    "event": "output_with_choose_msg",
    "node_id": "output_xxx",
    "node_execution_id": "xxxxxxxxx",
    "message_id": "xxxxx",
    "output_schema": {
        "message": "输出内容",
        "output_key": "output",
        "files": [
            {
                "path": "http://minio:9000/xxx.png?aa=xxx",
                "name": "测试图片.png"
            }
        ],
        "source_url": ""
    },
    "input_schema": {
        "input_type": "message_inline_option",
        "value": [
            {
                "key": "output_result",
                "type": "select",
                "value": "",
                "options": [
                    {
                        "id": "e2107f75",
                        "label": "选项1",
                        "value": ""
                    },
                    {
                        "id": "790c36f9",
                        "label": "选项2",
                        "value": ""
                    }
                ]
            }
        ]
    }
}`})})]})})]}),e.jsxs("div",{className:"mb-6",children:[e.jsx("p",{className:"eagent-label py-2",children:"处理逻辑："}),e.jsxs("ul",{className:"list-disc list-inside pl-4 mt-2 eagent-label pb-2",children:[e.jsxs("li",{className:"mt-2 leading-6",children:["展示 ",e.jsx("code",{className:"bg-gray-200 p-1 rounded",children:"output_schema"})," 内容"]}),e.jsxs("li",{className:"mt-2 leading-6",children:["根据 ",e.jsx("code",{className:"bg-gray-200 p-1 rounded",children:"input_schema"})," 在消息体中绘制选项"]}),e.jsx("li",{className:"mt-2 leading-6",children:"接收到用户选择动作后，拼接接口的入参，再次调用 API，示例如下："})]})]}),e.jsx(l,{className:"w-full overflow-auto custom-scroll",language:"json",style:n.oneDark,children:`{
    "workflow_id": "xxxxx",
    "session_id": "使用接口返回的session_id",
    "message_id": "xxxxxx",
    "input": {
        "output_xxx": {  # 事件里的节点ID
            # key是input_schema.value中元素的key
            "output_result": "e2107f75"  # 用户选择选项对应的id
        }
    }
}`}),e.jsx("h3",{className:"mt-8",id:"guide-9",children:"流式输出事件-输出中"}),e.jsx("p",{className:"eagent-label mt-2",children:"事件数据示例"}),e.jsx(l,{className:"w-full overflow-auto custom-scroll",language:"json",style:n.oneDark,children:`{
  "event": "stream_msg",
  "node_id": "llm_xxx",
  "node_execution_id": "xxxxxx",
  "status": "stream",
  "output_schema": {
    "message": "你",
    "reasoning_content": "",  # 深度思考的内容，message内容不为空代表深度思考结束
    "output_key": "output_1" # output_1 是节点中的输出变量名
  }
}`}),e.jsxs("div",{className:"mb-6",children:[e.jsx("p",{className:"eagent-label py-2",children:"调用方处理示例"}),e.jsxs("ul",{className:"list-disc list-inside pl-4 mt-2 eagent-label pb-2",children:[e.jsxs("li",{className:"mt-2 leading-6",children:[e.jsx("code",{className:"bg-gray-200 p-1 rounded",children:'status="stream"'})," 代表当处于流式输出中，需要根据 ",e.jsx("code",{className:"bg-gray-200 p-1 rounded",children:"node_execution_id"})," 和 ",e.jsx("code",{className:"bg-gray-200 p-1 rounded",children:"output_schema.output_key"})," 来确定流式内容是否属于同一条消息（节点批量运行模式下，会共用同一个 ",e.jsx("code",{className:"bg-gray-200 p-1 rounded",children:"node_execution_id"}),"，所以需要根据 ",e.jsx("code",{className:"bg-gray-200 p-1 rounded",children:"output_key"})," 来区分是否是不同的消息）。"]}),e.jsxs("li",{className:"mt-2 leading-6",children:["如果找到对应的消息，则将 ",e.jsx("code",{className:"bg-gray-200 p-1 rounded",children:"message"})," 内容添加到对应的消息里。"]}),e.jsxs("li",{className:"mt-2 leading-6",children:["如果未找到对应的消息，则开启一条新的消息，并将 ",e.jsx("code",{className:"bg-gray-200 p-1 rounded",children:"message"})," 和后续此消息的 ",e.jsx("code",{className:"bg-gray-200 p-1 rounded",children:"message"})," 拼接在一起。"]})]})]}),e.jsx("h3",{className:"mt-8",id:"guide-10",children:"流式输出事件-结束"}),e.jsx("p",{className:"eagent-label mt-2",children:"事件数据示例"}),e.jsx(l,{className:"w-full overflow-auto custom-scroll",language:"json",style:n.oneDark,children:`{
  "event": "stream_msg",
  "node_id": "llm_xxx",
  "node_execution_id": "xxxxxx",
  "status": "end",  # end表示流式事件结束了
  "output_schema": {
    "message": "你好，这是流式完成后最终的答案",
    "reasoning_content": "",  # 深度思考的内容，message内容不为空代表深度思考结束
    "output_key": "output_1",
    "source_url": "" # 是否支持溯源请参考产品文档
  }
}`}),e.jsxs("div",{className:"mb-6",children:[e.jsx("p",{className:"eagent-label py-2",children:"处理逻辑"}),e.jsxs("ul",{className:"list-disc list-inside pl-4 mt-2 eagent-label pb-2",children:[e.jsxs("li",{className:"mt-2 leading-6",children:["1. ",e.jsx("code",{className:"bg-gray-200 p-1 rounded",children:'status="end"'}),"代表流式输出完成，此时根据 node_execution_id 和 output_schema.output_key 找到对应的",e.jsx("code",{className:"bg-gray-200 p-1 rounded",children:"message"})]}),e.jsxs("li",{className:"mt-2 leading-6",children:["2. 使用 ",e.jsx("code",{className:"bg-gray-200 p-1 rounded",children:"message"})," 内容覆盖之前流式输出的结果，显示最终完整答案"]})]})]}),e.jsx("h3",{className:"mt-8",id:"guide-11",children:"结束事件"}),e.jsx("div",{className:"border border-red-200 rounded-sm bg-orange-100 p-4 text-sm",children:e.jsxs("p",{className:"eagent-label",children:["当接收到 ",e.jsx("span",{className:"bg-orange-50",children:'event="close"'})," 时，代表工作流已运行结束"]})}),e.jsx("p",{className:"eagent-label mt-2",children:"事件数据示例"}),e.jsx(l,{className:"w-full overflow-auto custom-scroll",language:"json",style:n.oneDark,children:`{
  "event": "close",
  "unique_id": "xxxxxx",
  "status": "end",
  "output_schema": {
    "message": {
        "code": "500",
        "message": "报错内容"
    }# 如果为空表示工作流正常结束；如果不为空则表示执行出错，内容就是错误信息
  }
}`}),e.jsxs("div",{className:"mb-6",children:[e.jsx("p",{className:"eagent-label py-2",children:"处理逻辑"}),e.jsxs("ul",{className:"list-disc list-inside pl-4 mt-2 eagent-label pb-2",children:[e.jsx("li",{className:"mt-2 leading-6",children:"判断message是否为空，为空则告知用户工作流运行结束"}),e.jsx("li",{className:"mt-2 leading-6",children:"如果message不为空，则告知用户工作流运行失败，并把报错信息抛出给用户或者自行处理"})]})]}),e.jsxs(g,{children:[e.jsx(N,{children:e.jsx(t,{children:e.jsx(i,{className:"w-[100%]",children:s("api.example")})})}),e.jsx(_,{children:e.jsx(t,{children:e.jsx(r,{className:"align-top",children:e.jsx(l,{className:"w-full overflow-auto custom-scroll",language:"json",style:n.oneDark,children:`500: 服务端异常，查看后端日志解决
10527: 工作流等待用户输入超时
10528: 节点执行超过最大次数
10531: <节点名称>功能已升级，需删除后重新拖入。
10532: 工作流版本已升级，请联系创建者重新编排
10540: 服务器线程数已满，请稍候再试`})})})})]})]})]})]})},pe=({})=>{const{t:s}=I(),{flow:o,getTweak:x,tabsState:d}=y.useContext(ee),c=oe(o,x,d),h=xe(o,x,d),{message:p}=B(),j=S=>{D(S.target).then(()=>{p({variant:"success",description:s("api.copySuccess")})})},[m,A]=y.useState(!1),P=S=>{A(!0),D(S).then(()=>{setTimeout(()=>{A(!1)},2e3)})};return e.jsxs("section",{className:"max-w-[1600px] flex-grow",children:[e.jsxs(f,{className:"mb-8",children:[e.jsx(w,{children:e.jsx(v,{children:s("api.apiRequestExample")})}),e.jsxs(k,{children:[e.jsxs("h3",{className:"mb-2 bg-secondary px-4 py-2 inline-flex items-center rounded-md gap-1",children:[e.jsx(u,{children:"POST"})," ",e.jsxs("span",{className:"hover:underline cursor-pointer",onClick:j,children:["/api/v1/process/",o.id]})]}),e.jsxs("p",{className:"my-2",children:[s("api.exampleCode"),"："]}),e.jsxs(H,{defaultValue:"curl",className:"w-full mb-[40px]",children:[e.jsxs(Q,{className:"",children:[e.jsx(z,{value:"curl",className:"",children:"cURL"}),e.jsx(z,{value:"python",children:"Python API"})]}),e.jsxs(E,{value:"curl",className:"relative",children:[e.jsx("button",{className:"absolute right-0 flex items-center gap-1.5 rounded bg-none p-1 text-xs text-gray-500 dark:text-gray-300",onClick:()=>P(c),children:m?e.jsx(T,{size:18}):e.jsx(q,{size:15})}),e.jsx(l,{className:"w-full overflow-auto custom-scroll",language:"bash",style:n.oneDark,children:c})]}),e.jsxs(E,{value:"python",className:"relative",children:[e.jsx("button",{className:"absolute right-0 flex items-center gap-1.5 rounded bg-none p-1 text-xs text-gray-500 dark:text-gray-300",onClick:()=>P(h),children:m?e.jsx(T,{size:18}):e.jsx(q,{size:15})}),e.jsx(l,{className:"w-full overflow-auto custom-scroll",language:"python",style:n.oneDark,children:h})]})]})]})]}),e.jsxs(f,{className:"mb-8",children:[e.jsx(w,{children:e.jsx(v,{children:s("api.requestParams")})}),e.jsx(k,{children:e.jsxs(g,{children:[e.jsx(N,{children:e.jsxs(t,{children:[e.jsxs(i,{className:"w-[60%]",children:[s("api.bodyParams")," ",e.jsx("span",{className:"bg-secondary px-2 py-1 rounded-md text-sm",children:"application/json"})]}),e.jsx(i,{children:s("api.example")})]})}),e.jsx(_,{children:e.jsxs(t,{children:[e.jsxs(r,{className:"align-top",children:[e.jsx(a,{name:"flow_id",required:!0,type:"UUID",desc:s("api.skillId"),remark:s("api.urlParam")}),e.jsx(a,{name:"inputs",required:!0,type:"Json",desc:s("api.skillInput"),example:'{"query":"什么是金融"}',remark:s("api.singleInput")}),e.jsx(a,{name:"history_count",type:"int",desc:s("api.historyCount")}),e.jsx(a,{name:"clear_cache",type:"boolean",desc:s("api.clearCache")}),e.jsx(a,{name:"session_id",type:"str",desc:s("api.sessionId"),remark:s("api.sessionRemark")}),e.jsxs(a,{name:"tweaks",required:!0,type:"Json",desc:s("api.tweaks"),remark:s("api.tweaksRemark"),children:[e.jsx(a,{line:!0,name:"ChatOpenAI-MzIaC",type:"Json",desc:s("api.exampleComponent"),example:'{"openai_api_key": "sk-xxx"} 或者 {}',remark:s("api.defaultConfig")}),e.jsx(a,{line:!0,name:"...",type:"Json",desc:s("api.componentParams")})]})]}),e.jsx(r,{className:"align-top",children:e.jsx(l,{className:" w-full overflow-auto custom-scroll",language:"json",style:n.oneDark,children:`{
  "inputs": {
    "query": "总结下文档内容"
  },
  "tweaks": {
    "Milvus-f74d8": {
      "collection_id": "10"
    },
    "ChatOpenAI-7f49c": {},
    "ElasticKeywordsSearch-0d2c8": {},
    "BishengRetrievalQA-7e0ae": {}
  },
  "history_count": 10,
  "clear_cache": false
}`})})]})})]})})]}),e.jsxs(f,{children:[e.jsx(w,{children:e.jsx(v,{children:s("api.responseData")})}),e.jsx(k,{children:e.jsxs(g,{children:[e.jsx(N,{children:e.jsxs(t,{children:[e.jsx(i,{className:"w-[60%]",children:s("api.dataStructure")}),e.jsx(i,{className:"w-[40%]",children:s("api.example")})]})}),e.jsx(_,{children:e.jsxs(t,{children:[e.jsx(r,{className:"align-top",children:e.jsxs(a,{name:"data",type:"object",desc:s("api.returnContent"),children:[e.jsx(a,{line:!0,name:"session_id",type:"string",desc:s("api.sessionIdReturn")}),e.jsxs(a,{line:!0,name:"result",type:"object",desc:s("api.skillResult"),children:[e.jsx(a,{line:!0,name:"answer",type:"string",desc:s("api.llmAnswer")}),e.jsx(a,{line:!0,name:"message_id",type:"int",desc:s("api.messageId")}),e.jsx(a,{line:!0,name:"source",type:"int",desc:s("api.source")}),e.jsx(a,{line:!0,name:"{key}",type:"string",desc:s("api.dynamicKey")})]})]})}),e.jsx(r,{className:"align-top",children:e.jsx(l,{className:"w-full max-w-[40vw] overflow-auto custom-scroll",language:"json",style:n.oneDark,children:`{
  "status_code": 200,
  "status_message": "SUCCESS",
  "data": {
    "result": {
      "result": "文档内容是关于电力集团关键信息基础设施网络安全保护的标准起草。文档以“基于管理防护要求”为主题，参考知识库内容，根据模版撰写相应内容。这份文档的撰写要求是不少于500字，不允许使用markdown格式，每行需要缩进两格。",
      "doc": [
        {
          "title": "关基网络安全保护工作指南.docx",
          "url": "www.baidu.com"
        }
      ],
      "source": 3,
      "message_id": 1322,
      "answer": "文档内容是关于电力集团关键信息基础设施网络安全保护的标准起草。文档以“基于管理防护要求”为主题，参考知识库内容，根据模版撰写相应内容。"
    },
    "session_id": "AUU629:059865218b3e895f103dbcad4d1b60ee40157191800f3aa8adaa12488f2cf82b",
    "backend": "anyio"
  }
}`})})]})})]})})]}),e.jsxs(f,{className:"mt-8",children:[e.jsx(w,{children:e.jsx(v,{children:s("api.useCase")})}),e.jsxs(k,{children:[e.jsx("h3",{className:"text-lg font-medium mb-2",children:s("api.knowledgeQADemo")}),e.jsx(l,{className:" w-full overflow-auto custom-scroll",language:"python",style:n.oneDark,children:`import requests
from typing import Optional
BASE_API_URL = "http://{IP}:{port}/api/v1/process"
FLOW_ID = "your flow_id"
# You can tweak the flow by adding a tweaks dictionary
# e.g {"OpenAI-XXXXX": {"model_name": "gpt-4"}}
TWEAKS = {
  "ConversationChain-A1J5d": {},
  "ProxyChatLLM-NloT5": {}
}
def run_flow(inputs: dict, flow_id: str, tweaks: Optional[dict] = None) -> dict:
    api_url = f"{BASE_API_URL}/{flow_id}"
    payload = {"inputs": inputs}
    if tweaks:
        payload["tweaks"] = tweaks
    response = requests.post(api_url, json=payload)
    return response.json()
inputs = {"input":"什么是金融"}
print(run_flow(inputs, flow_id=FLOW_ID, tweaks=TWEAKS))`}),e.jsx("p",{className:"text-md text-gray-500 mb-2",children:s("api.specifyKnowledgeBase")}),e.jsx(l,{className:"w-full overflow-auto custom-scroll",language:"python",style:n.oneDark,children:`TWEAKS = {
  "ConversationChain-A1J5d": {},
   "Milvus-T3kRH": {"collection_id": "your collection_id"},
  "ProxyChatLLM-NloT5": {}
}`}),e.jsx("h3",{className:"text-lg font-medium mb-2 mt-12",children:s("api.reportGenerationDemo")}),e.jsx("p",{className:"text-md mb-2",children:s("api.step1")}),e.jsx("p",{className:"text-md text-gray-500 mb-2",children:s("api.dependenciesDescription")}),e.jsx("p",{className:"text-md mb-2",children:s("api.step2")}),e.jsx("p",{className:"text-md text-gray-500 mb-2",children:s("api.uploadFiles")}),e.jsx(l,{className:" w-full overflow-auto custom-scroll",language:"python",style:n.oneDark,children:`import requests
def upload_file(local_path: str):
    server = "http://ip:port"
    url = server + '/api/v1/knowledge/upload'
    headers = {}
    files = {'file': open(local_path, 'rb')}
    res = requests.post(url, headers=headers, files=files)
    file_path = res.json()['data'].get('file_path', '')
    return file_path
    
 financeA = upload_file("caibao.pdf")
 financeB = upload_file("caibao2.pdf")`}),e.jsx("p",{className:"text-md mb-2",children:s("api.step3")}),e.jsx(l,{className:"w-full overflow-auto custom-scroll",language:"python",style:n.oneDark,children:`tweaks = {
  "InputFileNode-ozsI2": {"file_path": financeA},
  "InputFileNode-16U46": {"file_path": financeB},
  "Milvus-6HDPE": {"collection_name": "tmp", "drop_old": True} 
}`}),e.jsx("p",{className:"text-md mb-2",children:s("api.step4")}),e.jsx(l,{className:"w-full overflow-auto custom-scroll",language:"bash",style:n.oneDark,children:`response = requests.post(url="http://192.168.106.120:3002/api/v1/process/940a528f-eccc-4d43-aa19-55c4725645cf",
    json={"inputs": {"report_name":"","id":"Report-tuc6Q"}, "tweaks": tweaks})

print(response.text)`})]})]})]})},K=[{label:"24 小时",value:1},{label:"3 天",value:3},{label:"7 天",value:7},{label:"30 天",value:30},{label:"永久有效",value:0}],he={assistant:"assistant",skill:"skill",flow:"workflow"};function je({type:s="assistant"}){var J;const{t:o}=I(),{id:x}=U(),{toast:d}=B(),[c,h]=y.useState(""),[p,j]=y.useState(1),[m,A]=y.useState(""),[P,S]=y.useState(!1),[F,O]=y.useState(!1),R=c.length===0||c.length===6,W=async()=>{if(c.length>0&&c.length!==6){d({title:"密码必须为6位字符",variant:"error"});return}S(!0);try{const b=he[s]??s,L=await se.post("/api/v1/share-link/generate_share_link",{resource_type:b,resource_id:x,share_mode:"read_only",expire_days:p,meta_data:{flowId:x},password:c.length===6?c:null}),M=L==null?void 0:L.share_token;if(!M)throw new Error("未获取到 share_token");const Y=`${location.origin}/workspace/share/${M}`;A(Y)}catch{d({title:"生成失败，请重试",variant:"error"})}finally{S(!1)}},G=()=>{D(m).then(()=>{O(!0),setTimeout(()=>O(!1),2e3)})};return e.jsxs("section",{className:"pb-20 max-w-2xl pt-4",children:[e.jsx("p",{className:"text-sm text-muted-foreground mb-6",children:"生成一个网页访问链接，访客无需登录账号，输入密码即可直接使用该智能体。"}),e.jsxs("div",{className:"mb-6",children:[e.jsxs($,{className:"mb-2 block font-medium",children:["访问密码",e.jsx("span",{className:"text-muted-foreground font-normal ml-2 text-xs",children:"（6位任意字符，留空则无需密码）"})]}),e.jsx(me,{value:c,onChange:b=>h(b.target.value),placeholder:"请输入6位密码，留空则不设置",maxLength:6,className:`w-64 ${R?"":"border-red-400"}`}),!R&&e.jsx("p",{className:"text-red-400 text-xs mt-1",children:"密码长度必须为6位"})]}),e.jsxs("div",{className:"mb-8",children:[e.jsx($,{className:"mb-2 block font-medium",children:"链接有效期"}),e.jsxs(ae,{value:String(p),onValueChange:b=>j(Number(b)),children:[e.jsx(le,{className:"w-40",children:e.jsx(ne,{})}),e.jsx(te,{children:K.map(b=>e.jsx(ie,{value:String(b.value),children:b.label},b.value))})]})]}),e.jsx(V,{onClick:W,disabled:P||!R,className:"mb-6",children:P?"生成中...":"生成链接"}),m&&e.jsxs(f,{children:[e.jsx(w,{className:"pt-3 pb-1",children:e.jsxs(v,{className:"flex items-center justify-between text-sm",children:[e.jsxs("span",{className:"flex items-center gap-1.5",children:[e.jsx(Z,{size:15}),"访问链接"]}),e.jsxs("button",{onClick:G,className:"flex items-center gap-1 text-xs text-muted-foreground hover:text-foreground",children:[F?e.jsx(T,{size:14}):e.jsx(q,{size:14}),F?"已复制":"复制"]})]})}),e.jsxs(k,{children:[e.jsx("p",{className:"text-xs break-all text-muted-foreground bg-muted rounded p-2",children:m}),e.jsxs("div",{className:"mt-3 text-xs text-muted-foreground space-y-1",children:[c.length===6&&e.jsxs("p",{children:["密码：",e.jsx("span",{className:"font-mono font-medium text-foreground",children:c})]}),e.jsxs("p",{children:["有效期：",(J=K.find(b=>b.value===p))==null?void 0:J.label]})]})]})]})]})}const Se=({type:s="assistant"})=>{const{t:o}=I(),[x,d]=y.useState("api-access"),c=y.useMemo(()=>[{key:"api-access",labelKey:o("api.apiAccess"),component:ge(s)},{key:"web-publish",labelKey:o("api.webPublish"),component:e.jsx(je,{type:s})}],[s]),h=y.useMemo(()=>{var p;return(p=c.find(j=>j.key===x))==null?void 0:p.component},[x,c]);return e.jsxs("div",{className:"flex size-full bg-background-main",children:[e.jsx(Ne,{items:c,activeKey:x,onChange:d}),e.jsx("main",{className:"flex-1 p-2 pl-0 overflow-y-auto",style:{scrollBehavior:"smooth"},children:h})]})},ge=s=>({assistant:e.jsx(X,{}),skill:e.jsx(pe,{}),flow:e.jsx(ue,{})})[s]||e.jsx(X,{}),Ne=({items:s,activeKey:o,onChange:x})=>e.jsx("aside",{className:"w-52 flex-shrink-0",children:e.jsx("nav",{className:"p-2",children:e.jsx("ul",{className:"space-y-4",children:s.map(d=>e.jsx("li",{children:e.jsx("button",{role:"tab","aria-selected":o===d.key,className:`w-full text-left p-2 pl-6 rounded transition-colors ${o===d.key?"bg-card hover:bg-card/90":"hover:bg-card/50"}`,onClick:()=>x(d.key),children:d.labelKey})},d.key))})})});export{Se as A};
