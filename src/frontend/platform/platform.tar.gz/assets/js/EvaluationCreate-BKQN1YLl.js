import{r as n,j as e,cm as $,cf as ee,cD as te,ci as se,dA as ae,cs as ne,el as re,em as oe,ed as ie}from"./vendor-CuSD6Dcv.js";import{S as le}from"./index-B0olF4xL.js";import{ad as R,G as b,k as S,l as D,m as A,n as C,w as P,o as f,B as I}from"./shared-components-DtfXUKAu.js";import{I as ce}from"./index-BnjExYcV.js";import{P as ue,L as de,u as he,Q as pe,c as me,w as Q}from"./index-vqt98QkI.js";import{c as fe}from"./evaluate-BI57JHcS.js";import{u as xe}from"./reactdrop-BRLYmmvL.js";import{G as W}from"./index-Bor5j3Ho.js";import"./reactflow-D5WjbByq.js";import"./index-QkmTdepa.js";import"./constants-Bpk9IYB1.js";function we({field_name:s,setNodeClass:x,nodeClass:p,value:N,onChange:a,disabled:u,editNode:o=!1,type:w=R.PROMPT}){const[i,m]=n.useState(N),{openPopUp:v}=n.useContext(ue);n.useEffect(()=>{u&&(m(""),a(""))},[u,a]);const g=l=>{m(l),a(l)};return e.jsx("div",{className:u?"pointer-events-none w-full ":"w-full",children:e.jsxs("div",{className:"flex w-full items-center",children:[e.jsx("span",{onClick:()=>{v(e.jsx(W,{type:w,value:i,buttonText:"check & Save",modalTitle:"Edit Prompt",setValue:l=>{m(l),a(l)},nodeClass:p,setNodeClass:x}))},className:o?"input-edit-node input-dialog":(u?" input-disable text-ring ":"")+" whitespace-wrap input-primary",children:i!==""?i:"enter your prompt"}),e.jsx("button",{onClick:()=>{v(e.jsx(W,{field_name:s,type:R.PROMPT,value:i,buttonText:"check & Save",modalTitle:"Edit Prompt",setValue:g,nodeClass:p,setNodeClass:x}))},children:!o&&e.jsx($,{strokeWidth:1.5,className:"icons-parameters-comp"+(u?" text-ring":" hover:text-accent-foreground")})})]})})}const ve=`Extract following from given question and ground truth

Question:What powers the sun and what is its primary function?
Answer: The sun is powered by nuclear fission, similar to nuclear reactors on Earth, and its primary function is to provide light to the solar system.
Ground truth: The sun is actually powered by nuclear fusion, not fission. In its core, hydrogen atoms fuse to form helium, releasing a tremendous amount of energy. This energy is what lights up the sun and provides heat and light, essential for life on Earth. The sun's light also plays a critical role in Earth's climate system and helps to drive the weather and ocean currents.
Extracted statements:
[
{{
  "statements that are present in both the answer and the ground truth": ["The sun's primary function is to provide light"],
  "statements present in the answer but not found in the ground truth": ["The sun is powered by nuclear fission", "similar to nuclear reactors on Earth"],
  "relevant statements found in the ground truth but omitted in the answer": ["The sun is powered by nuclear fusion, not fission", "In its core, hydrogen atoms fuse to form helium, releasing a tremendous amount of energy", "This energy provides heat and light, essential for life on Earth", "The sun's light plays a critical role in Earth's climate system", "The sun helps to drive the weather and ocean currents"]
}}
]

Question: What is the boiling point of water?
Answer: The boiling point of water is 100 degrees Celsius at sea level.
Ground truth: The boiling point of water is 100 degrees Celsius (212 degrees Fahrenheit) at sea level, but it can change with altitude.
Extracted statements:
[
  {{
    "statements that are present in both the answer and the ground truth": ["The boiling point of water is 100 degrees Celsius at sea level"],
    "statements present in the answer but not found in the ground truth": [],
    "relevant statements found in the ground truth but omitted in the answer": ["The boiling point can change with altitude", "The boiling point of water is 212 degrees Fahrenheit at sea level"]
  }}
]

Question: What was the company's R&D expense as a percentage of revenue in 2021?
Answer: According to the information provided, the company's R&D expense accounted for 15.86% of revenue in 2021.
Ground truth: According to the company's prospectus data, the company's R&D expense accounted for 15.86% of revenue in 2021.
Extracted statements:
[
  {{
    "statements that are present in both the answer and the ground truth": ["The company's R&D expense accounted for 15.86% of revenue in 2021"],
    "statements present in the answer but not found in the ground truth": [],
    "relevant statements found in the ground truth but omitted in the answer": []
  }}
]

Question: What was the EBITDA of Dameng in 2021?
Answer: Dameng's EBITDA in 2021 was 491,898,700 yuan.
Ground truth: According to Dameng Database's prospectus data, Dameng's EBITDA in 2021 was 491,898,500 yuan.
Extracted statements:
[
  {{
    "statements that are present in both the answer and the ground truth": [],
    "statements present in the answer but not found in the ground truth": ["Dameng's EBITDA in 2021 was 491,898,700 yuan"],
    "relevant statements found in the ground truth but omitted in the answer": ["According to Dameng Database's prospectus data, Dameng's EBITDA in 2021 was 491,898,500 yuan"]
  }}
]

Question: What was Dameng's accounts receivable turnover ratio in 2022?
Answer: Based on the information provided, Dameng's accounts receivable turnover ratio in 2022 is unknown.
Ground truth: Sorry, Dameng has not yet disclosed its 2022 annual report data.
Extracted statements:
[
  {{
    "statements that are present in both the answer and the ground truth": ["Dameng's 2022 accounts receivable turnover ratio is unknown"],
    "statements present in the answer but not found in the ground truth": [],
    "relevant statements found in the ground truth but omitted in the answer": [],
  }}
]


Question:{question}
Answer: {answer}
Ground truth: {ground_truth}
Extracted statements:"""`;var ge={BASE_URL:""};function Re(){var G,M;const{t:s}=ee(),{id:x}=te(),{flow:p}=n.useContext(de),{toast:N}=he();n.useMemo(()=>x?p:null,[p]);const[a,u]=n.useState(""),[o,w]=n.useState(""),[i,m]=n.useState(""),[v,g]=n.useState(""),[l,L]=n.useState([]),[T,z]=n.useState(ve),[V,q]=n.useState(""),[F,B]=n.useState(!1),d=n.useRef(null),U=t=>{var _;const r=t[0];if(!r)return;const h=(_=r.name.split(".").pop())==null?void 0:_.toLowerCase();d.current=t[0];const j=d.current.size,y=[];if(h!=="csv"){y.push(s("evaluation.onlyCsvAllowed")),d.current=null,c(y);return}if(j>10*1024*1024)return y.push(s("evaluation.fileSizeLimit")),d.current=null,c(y);const Z=t[0].name;q(Z)},{getRootProps:O,getInputProps:K,isDragActive:je,rejectedFiles:ye}=xe({accept:{"text/csv":[".csv"],"application/csv":[".csv"],"application/vnd.ms-excel":[".csv"]},useFsAccessApi:!1,onDrop:U,maxFiles:1,onDropRejected:t=>{var r;if(t.length>0){const j=(r=t[0].file.name.split(".").pop())==null?void 0:r.toLowerCase();c(j==="xlsx"||j==="xls"?[s("evaluation.excelNotSupported")]:[s("evaluation.onlyCsvSupported")])}}}),E=se(),H=async()=>{const t=[];if(a||t.push(s("evaluation.enterExecType")),a&&!o&&(a==="workflow"&&t.push(s("evaluation.selectWorkflow")),a==="flow"&&t.push(s("evaluation.selectSkill")),a==="assistant"&&t.push(s("evaluation.selectAssistant"))),o&&(a==="workflow"||a==="flow")&&!i&&t.push(s("evaluation.selectVersion")),!d.current&&o&&((a==="workflow"||a==="flow")&&i||a==="assistant")&&t.push(s("evaluation.enterFile")),T||t.push(s("evaluation.enterPrompt")),t.length)return c(t);B(!0);try{const r=new FormData;r.append("exec_type",a),r.append("unique_id",o),r.append("version",i),r.append("prompt",T),d.current&&r.append("file",d.current),await me(fe(r)),E(-1)}finally{B(!1)}},c=t=>{N({variant:"error",description:t})},X=t=>{g(""),t&&Q({page:1,pageSize:100,keyword:"",type:{workflow:"flow",assistant:"assistant",flow:"skill"}[t]}).then(h=>{L(h.data)})},J=()=>{const t=document.createElement("a");t.href=ge.BASE_URL+"/template.csv",t.download="template.csv",document.body.appendChild(t),t.click(),document.body.removeChild(t)},k=n.useCallback(ae(t=>{a&&Q({page:1,pageSize:100,keyword:t,type:{workflow:"flow",assistant:"assistant",flow:"skill"}[a]}).then(h=>{L(h.data)})},300),[a]),Y=t=>{g(t.target.value),k(t.target.value)};return n.useEffect(()=>()=>{k.cancel()},[k]),e.jsx("div",{className:"relative box-border h-full overflow-auto",children:e.jsxs("div",{className:"h-full overflow-y-auto p-6 pb-48",children:[e.jsx("div",{className:"flex w-full justify-between",children:e.jsx(le,{content:s("back"),side:"right",children:e.jsx("button",{className:"extra-side-bar-buttons w-[36px]",onClick:()=>E(-1),children:e.jsx(ne,{strokeWidth:1.5,className:"side-bar-button-size"})})})}),e.jsxs("div",{className:"pt-6",children:[e.jsx("p",{className:"text-center text-2xl",children:s("evaluation.createTitle")}),e.jsx("div",{className:"mx-auto mt-4 w-full max-w-3xl",children:e.jsxs("div",{className:"w-full overflow-hidden px-1 transition-all space-y-8",children:[e.jsxs("div",{className:"flex items-center justify-between gap-1",children:[e.jsx(b,{className:"w-[180px] text-right",children:s("evaluation.selectLabel")}),e.jsxs("div",{className:"flex flex-1 gap-2",children:[e.jsxs(S,{value:a,onValueChange:t=>{u(t),w(""),X(t)},children:[e.jsx(D,{children:e.jsx(A,{className:"mt-2 w-auto",placeholder:s("evaluation.selectPlaceholder")})}),e.jsx(C,{children:e.jsxs(P,{children:[e.jsx(f,{value:"flow",children:s("build.skill")}),e.jsx(f,{value:"assistant",children:s("build.assistant")}),e.jsx(f,{value:"workflow",children:s("build.workFlow")})]})})]}),e.jsxs(S,{value:o,onValueChange:t=>w(t),onOpenChange:()=>{if(!a)return c([s("evaluation.enterExecType")])},children:[e.jsx(D,{slot:"",className:"max-w-[200px]",children:e.jsx(A,{className:"mt-2 max-w-[200px]",placeholder:s("evaluation.selectPlaceholder")})}),e.jsxs(C,{children:[e.jsx(ce,{value:v,onChange:Y,autoFocus:!0,className:"my-2 mx-auto",placeholder:s("evaluation.selectInputPlaceholder"),onKeyDown:t=>t.stopPropagation()}),e.jsx(re,{className:"h-80",children:e.jsx(P,{children:l.map(t=>e.jsx(f,{value:t.id,children:t.name},t.id))})})]})]}),(a==="workflow"||a==="flow")&&e.jsxs(S,{value:i,onValueChange:t=>m(t),onOpenChange:()=>{if(!o){if(a==="workflow")return c([s("evaluation.selectWorkflow")]);if(a==="flow")return c([s("evaluation.selectSkill")])}},children:[e.jsx(D,{className:"min-w-[50px]",children:e.jsx(A,{className:"mt-2",placeholder:s("evaluation.selectPlaceholder")})}),e.jsx(C,{children:e.jsx(P,{children:(M=(G=oe(l,{id:o}))==null?void 0:G.version_list)==null?void 0:M.map(t=>e.jsx(f,{value:t.id,children:t.name},t.id))})})]})]})]}),e.jsxs("div",{className:"flex items-center gap-1",children:[e.jsx("div",{className:"min-w-[180px] text-right",children:e.jsx(b,{className:"whitespace-nowrap",children:s("evaluation.dataLabel")})}),e.jsxs("div",{className:"flex flex-1 items-center justify-between",children:[e.jsxs("div",{...O(),className:"flex w-0 flex-1 items-center",children:[e.jsx("input",{...K()}),e.jsxs("div",{className:"flex cursor-pointer text-sm items-center justify-center rounded-md border px-[12px] py-[6px] hover:border-primary",children:[e.jsx(ie,{size:14}),e.jsx("span",{className:"whitespace-nowrap",children:s("code.uploadFile")})]}),V&&e.jsx("div",{className:"ml-2 truncate",children:V}),e.jsxs(b,{className:"whitespace-nowrap",children:[" ",s("evaluation.fileExpandName")," csv"]})]}),e.jsx(I,{className:"ml-2",variant:"link",onClick:J,children:s("evaluation.downloadTemplate")})]})]}),e.jsxs("div",{className:"flex items-center justify-between gap-1",children:[e.jsx("div",{className:"min-w-[180px] text-right",children:e.jsxs(b,{className:"flex items-center justify-end",children:[e.jsx(pe,{content:s("evaluation.tooltip")}),s("evaluation.promptLabel")]})}),e.jsx("div",{className:"flex-1",style:{width:"calc(100% - 180px)"},children:e.jsx(we,{field_name:"prompt",editNode:!1,disabled:!1,type:R.TEXT,value:T,onChange:t=>{z(t)}})})]}),e.jsxs("div",{className:"flex",children:[e.jsx("div",{className:"min-w-[180px]"}),e.jsxs("div",{className:"flex flex-1 gap-4",children:[e.jsx(I,{disabled:F,className:"extra-side-bar-save-disable flex-1",onClick:H,children:s("evaluation.create")}),e.jsx(I,{disabled:F,className:"flex-1",variant:"outline",onClick:()=>E(-1),children:s("evaluation.cancel")})]})]})]})})]})]})})}export{Re as default};
